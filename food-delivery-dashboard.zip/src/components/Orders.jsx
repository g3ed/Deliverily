const orders = [
  { id: 1, name: "Burger", status: "On Process", price: "$12.99" },
  { id: 2, name: "Pizza", status: "Completed", price: "$15.99" },
  { id: 3, name: "Sushi", status: "Pending", price: "$22.50" },
];

const Orders = () => {
  return (
    <div className="bg-white shadow-md p-4 rounded-lg">
      <h3 className="text-xl font-semibold mb-3">Recent Orders</h3>
      <ul>
        {orders.map((order) => (
          <li key={order.id} className="flex justify-between py-2 border-b">
            <span>{order.name}</span>
            <span className="text-gray-500">{order.status}</span>
            <span className="font-bold">{order.price}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Orders;