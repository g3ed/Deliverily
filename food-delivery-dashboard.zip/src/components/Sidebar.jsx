import { FaHome, FaList, FaChartPie } from "react-icons/fa";

const Sidebar = () => {
  return (
    <div className="w-64 h-screen bg-green-600 text-white p-5">
      <h2 className="text-2xl font-bold mb-6">🍔 Food Dashboard</h2>
      <ul>
        <li className="flex items-center mb-4 p-2 cursor-pointer hover:bg-green-700 rounded">
          <FaHome className="mr-2" /> Home
        </li>
        <li className="flex items-center mb-4 p-2 cursor-pointer hover:bg-green-700 rounded">
          <FaList className="mr-2" /> Orders
        </li>
        <li className="flex items-center mb-4 p-2 cursor-pointer hover:bg-green-700 rounded">
          <FaChartPie className="mr-2" /> Statistics
        </li>
      </ul>
    </div>
  );
};

export default Sidebar;