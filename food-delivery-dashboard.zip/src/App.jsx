import Sidebar from "./components/Sidebar";
import Navbar from "./components/Navbar";
import StatsCard from "./components/StatsCard";
import Orders from "./components/Orders";

const App = () => {
  return (
    <div className="flex">
      <Sidebar />
      <div className="flex-1 p-5 bg-gray-100">
        <Navbar />
        <div className="grid grid-cols-3 gap-4 mt-5">
          <StatsCard title="Total Orders" value="1,245" />
          <StatsCard title="Revenue" value="$35,600" />
          <StatsCard title="Customers" value="350" />
        </div>
        <div className="mt-5">
          <Orders />
        </div>
      </div>
    </div>
  );
};

export default App;